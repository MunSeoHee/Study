class HomeController < ApplicationController
    
    def index
    end
    
    def event
    end
    
    def performance
    end
    
    def map
    end
    
end
