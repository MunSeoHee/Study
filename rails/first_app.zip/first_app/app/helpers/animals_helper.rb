module AnimalsHelper
end
