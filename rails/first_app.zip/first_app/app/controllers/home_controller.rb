class HomeController < ApplicationController    #상속받았음
  def index
   # render html: "당신은 #{request.remote_ip} 로 접속하셨습니다."       #순수문자만 : '', 문자+명령 : "#{}"
    @box = request.remote_ip  #@붙어줘야 views파일로 전달 가능
  end
end
