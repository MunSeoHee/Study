class MusicsController < ApplicationController
    
    def moon
    end
    def index
    end
end
