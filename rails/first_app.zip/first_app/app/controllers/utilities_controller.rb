class UtilitiesController < ApplicationController
  def index
  end

  def pick_lucky_numbers
    #@lucky_numbers = (1..45).to_a.sample 6 #(1..45)=1부터 45까지/to_a = to arr -> 범위를 배열로 바꿈
    numbers = (1..45).to_a
    random_numbers = numbers.sample 6
    @lucky_numbers = random_numbers.sort  #오름차순 정렬
    #lucky_numbers = (1..45).to_a.sample(6).sort
  end

  def get_stock_info
    # require 'stock_quote'
    
    
  end
  
  def show_stock_info
    #사용자가 get_stock_info에서 보낸 data
    #params[:company_code2] == params['company_code2']
    inputs = [ params['company_code1'], params[:company_code2], params['company_code3'] ]
    @stocks = StockQuote::Stock.quote(inputs)
  end
end
