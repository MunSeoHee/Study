class AnimalsController < ApplicationController
    def cat
        # 자동으로 < 컨트롤러 이름과 같은 폴더 안에 액션 이름과 같은 html파일을 보여줘라 >가 실행됨
    end
   
    def dog
    end
    
    def index
    end
    
end

#컨트롤러와 이름이 같은 views폴더에 있는 파일이 매칭됨