#print = 끝에 자동 엔터 X
#puts = 끝에 자동 엔터

# =>print "input your name : "
# =>name = gets.chomp  / chomp를 안 쓰면 엔터 값까지 받아버림
# =>print "your name is "
# =>puts name

# =>puts "숫자 6개를 입력하세요. 띄어쓰기로 구분하세요."
# =>num = gets.chomp
# =>str_array = num.split(" ") #스페이스 기준으로 나눔
# =>int_array = str_array.map(&:to_i) #i = int, 정수형으로 받아온다
# =>print "당신이 입력한 숫자는 #{int_array}" #문자열아닌 다른형과 같이 쓰는 거 #{정수, 기타 변수 등등}



# =>list = Array.new #list = Array.new == list = []

# =>6.times do |i|
   # => print "#{i+1}번째 숫자를 입력하세요: "
    # =>a = gets.chomp
   # => list << a
# =>end

# =>list.each do |x|
   # => puts "당신이 입력한 숫자는 #{x}입니다."
# =>end

=begin
puts "어떤 게임을 선택하시겠습니까?"
print "게임 number를 입력해 주세요. 1(행맨), 2(도미노), 3(사다리게임):"
a=gets.chomp
if a=='1'
    puts '행맨 시작'
elsif a=='2'
    puts '도미노 시작'
else
    puts '사다리게임 시작'
end
=end


