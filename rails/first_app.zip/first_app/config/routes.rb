Rails.application.routes.draw do
  get '/utilities/index' # => 'utilities#index' 생략되어있음

  get '/utilities/pick_lucky_numbers'

  get '/utilities/get_stock_info'
  
  get '/utilities/show_stock_info'



#   For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
    # root 'home#index' 밑에거랑 동일
    get '/' => 'home#index'     #/:맨처음 접속했을때 화면, /로 접속했을때 home컨트롤러로 보내라, 그리고 index를 실행해라 (#index)
    
    
    get '/animals/cat' => 'animals#cat'
    get '/animals/dog' => 'animals#dog'
    get '/animals' => 'animals#index' #URL과 컨트롤러 맞출 필요없음
    get '/music' => 'musics#index'
    get '/musics/moon' => 'musics#moon'
end
