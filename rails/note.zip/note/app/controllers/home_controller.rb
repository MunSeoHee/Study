class HomeController < ApplicationController
  def index
    @posts = Post.all    #모든 행 선택
  end

  def new
  end

  def create
    @post = Post.new      #테이블 한 행 만듦
    @post.title = params[:post_title]
    @post.content = params[:post_content]
    @post.save
    
    redirect_to '/home/index'
  end
  
  def show
    @post = Post.find(params[:post_id])
  end
  
  def destroy
    @post = Post.find(params[:post_id])
    @post.destroy
    redirect_to '/'
  end
  
  def edit
    @post = Post.find(params[:post_id])
  end
  
  def update
    @post=Post.find(params[:post_id])
    @post.title = params[:edit_post_title]
    @post.content = params[:edit_post_content]
    @post.save
    redirect_to "/home/show/#{@post.id}"
  end
  
end
