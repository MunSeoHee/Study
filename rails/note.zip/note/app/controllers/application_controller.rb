class ApplicationController < ActionController::Base
#   protect_from_forgery with: :exception   => 보안. 꺼야지 post방식 가능
end
