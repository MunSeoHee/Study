require 'nokogiri'
require 'rest-client'

class HomeController < ApplicationController
    
    def index
    end
    
    
    def dust
        url = 'https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%EB%B3%B5%EC%A0%95%EB%8F%99+%EB%AF%B8%EC%84%B8%EB%A8%BC%EC%A7%80'
        page = RestClient.get(url)
        doc=Nokogiri::HTML(page)
        info = doc.css('#main_pack > div.content_search.section._atmospheric_environment > div > div.contents03_sub > div > div:nth-child(4) > div.main_box.expand > div > div:nth-child(1) > div.state_info > span:nth-child(2) > em')
        @dust = info.text
        
        dustCal(@dust.to_i)
        
            
        # doc = Nokogiri::HTML(open('https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&query=%EB%B3%B5%EC%A0%95+%EB%AF%B8%EC%84%B8%EB%A8%BC%EC%A7%80&oquery=%EB%B3%B5%EC%A0%95+%EB%AF%B8%EC%84%B8%EB%A8%BC%EC%A7%80&tqi=TY0hCwpVuF4ssuU2b5NssssssKZ-292839'))
        # @num = doc.css('#main_pack > div.content_search.section._atmospheric_environment > div > div.contents03_sub > div > div:nth-child(4) > div.main_box.expand > div > div:nth-child(1) > div.state_info > span:nth-child(2) > em')
    end
    
    def dustCal(value)
        if value > 50              #.to_i는 문자를 숫자로 바꿔줌
            @dustvalue = "매우 나쁨"
        else
            @dustvalue = "좋음"
    
        end
    end
    
    
end
