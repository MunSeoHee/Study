class DustHelper
    def dustHelper(value)
        return
    end
end

#사용시 컨트롤러에서

#require 'DustHelper'

#dust_helper = DustHelper.new
#dust_helper.dustHelper(dust)