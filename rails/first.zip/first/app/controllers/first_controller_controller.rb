class FirstControllerController < ApplicationController

def new #앞에 보이는 html파일이랑 이름 맞춰야됨
    @random = *(1..45) #1~45
    @lotto = @random.sample(7) #@는 인스턴스 변수를 나타낸다 #sample(7) : 랜덤으로 7개 뽑음
end

end
