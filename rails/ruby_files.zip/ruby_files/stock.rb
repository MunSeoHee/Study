require 'stock_quote'
# stocks = StockQuote::Stock.quote("amzn, tsla, appl, fb, googl")
# puts stock.latest_price 한개의 가장 최근 가격
# stocks.each do |stock|
    # puts stock.latest_price
# end

print '원하는 NASDAQ 주식의 심볼을 입력하세요 : '
input = gets.chomp
puts input
stock = StockQuote::Stock.quote(input)
puts stock.company_name
puts stock.latest_price