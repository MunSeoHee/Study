Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root 'home#index'
  get 'home/new' => 'home#new'
  get 'home/create' => 'home#create' 
  get 'home/show/:post_id' => 'home#show'
end
