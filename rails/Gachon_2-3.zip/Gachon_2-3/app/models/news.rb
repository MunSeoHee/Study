class News < ApplicationRecord
    has_many :comments
end
