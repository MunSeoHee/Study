module WriteHelper
end
