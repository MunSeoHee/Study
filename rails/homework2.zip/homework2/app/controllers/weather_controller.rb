#require 'httparty'

class WeatherController < ApplicationController
    
    def index
        resp = HTTParty.get("https://api2.sktelecom.com/weather/summary?version=2&lat=37.451009&lon=127.128880&appkey=fb487cf1-0815-4570-aa55-a00fc81abc08")
        info = resp.parsed_response["weather"]["summary"]
    
        info.each do |x|
            @name=x["today"]["sky"]["name"]
           
        end
        
        info.each do |x|
            @MAX_temp=x["today"]["temperature"]["tmax"]
        end
        
        info.each do |x|
            @MIN_temp=x["today"]["temperature"]["tmin"]
        end
    end
    
    def view
        @info1 = params[:lat]
        @info2 = params[:lon]
        resp = HTTParty.get("https://api2.sktelecom.com/weather/summary?version=2&lat=#{@info1}&lon=#{@info2}&appkey=fb487cf1-0815-4570-aa55-a00fc81abc08")
        info = resp.parsed_response["weather"]["summary"]
    
        info.each do |x|
            @name=x["today"]["sky"]["name"]
           
        end
        
        info.each do |x|
            @MAX_temp=x["today"]["temperature"]["tmax"]
        end
        
        info.each do |x|
            @MIN_temp=x["today"]["temperature"]["tmin"]
        end
        
        puts "===================================="
        puts @name, @MAX_temp, @MIN_temp
    end
end
