import MainController from '/homework2/app/assets/javascripts/MainController.js'

document.addEventListener('DOMContentLoaded', () => {
  MainController.init()
})