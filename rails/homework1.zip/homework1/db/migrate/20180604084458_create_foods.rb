class CreateFoods < ActiveRecord::Migration[5.0]
  def change
    create_table :foods do |t|
      t.string :title
      t.text :content
      t.string :img
      t.integer :like

      t.timestamps
    end
  end
end
