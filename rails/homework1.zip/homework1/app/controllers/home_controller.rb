class HomeController < ApplicationController
    def main
        n=1
        @img=Food.find(n).img
        @title = Food.find(n).title
        @content = Food.find(n).content
        @like = Food.find(n).like
    end
    
    def like
        new=Food.find 1
        new.like = Food.find(1).like+1
        new.save
        redirect_to "/home/main"
    end
end
