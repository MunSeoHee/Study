class Food < ApplicationRecord
end
