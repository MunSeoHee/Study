class Center < ApplicationRecord
    has_many :reviews
    self.per_page = 5
    searchable do
    text :title, :default_boost => 2 #제목
  end
end