class Review < ApplicationRecord
  belongs_to :center
end
