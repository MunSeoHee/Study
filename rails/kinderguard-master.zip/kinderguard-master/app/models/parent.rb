class Parent < ApplicationRecord
end
