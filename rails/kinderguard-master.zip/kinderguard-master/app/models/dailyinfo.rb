class Dailyinfo < ApplicationRecord
end
