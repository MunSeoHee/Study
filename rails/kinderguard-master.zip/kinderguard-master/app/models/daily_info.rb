class DailyInfo < ApplicationRecord
end
