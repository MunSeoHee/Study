require 'JsonHelper'
require 'date'
# Date.today.strftime("%m%d")
# include AbstractController::Rendering

class Scenario
    
    
def rule(userkey,message)
    jsonHelper = JsonHelper.new
    
    if message == "선생님"
        teacher_create = Parent.all.find_or_create_by(scenario:"1", kakao_id:"#{userkey}", state:"center_regi", registered:"0", usertype: message)
        teacher_create.save
        return jsonHelper.messageJson("어린이집 선생님이시군요!\n근무중인 어린이집 코드를 입력해주세요!")
    elsif message == "학부모"
        parent_create = Parent.all.find_or_create_by(scenario:"1", kakao_id:"#{userkey}", state:"center_regi", registered:"0", usertype: message)
        parent_create.save
        return jsonHelper.messageJson("학부모시군요!\n아이가 다니고 있는 어린이집 코드를 입력해주세요!")
    end
    
    if Parent.all.find_by(kakao_id: userkey).usertype == "선생님"
      @parent = Parent.all.find_by(kakao_id: userkey)
      @parent_scenario = Parent.all.find_by(kakao_id: userkey).scenario
      @parent_state = Parent.all.find_by(kakao_id: userkey).state
     
     
      if @parent_scenario == "1"
        if @parent_state == "center_regi"
            @parent.update(:center_code => message, :state => 'name_regi')
            return jsonHelper.messageJson("선생님 이름을 입력해주세요!")
         
        elsif @parent_state == "center_regi"
            @parent.update(:center_code => message, :state => 'name_regi')
            return jsonHelper.messageJson("선생님 이름을 입력해주세요!")
        elsif @parent_state == "name_regi"
            @parent.update(:name => message, :registered => '1', :scenario => '100', :state => 'init')
            @parent_name = @parent.name
            return jsonHelper.buttonJson("안녕하세요 #{@parent_name}선생님!\n등록이 완료되었습니다!",["시작하기"])

        end
        
      elsif @parent_scenario == "100"
        if @parent_state == "init"
          if message ==  "공지사항 입력하기"
            @parent.update(:state => 'input_notice')
            return jsonHelper.messageJson("공지사항을 입력해주세요!")
            
          elsif message == "바깥활동시간 입력하기"
            @parent.update(:state => 'input_outer')  
            return jsonHelper.messageJson("오늘의 바깥활동시간을 입력해주세요!(분)")
            
          elsif message == "식단 입력하기"
            @parent.update(:state => 'input_food_text')  
            return jsonHelper.messageJson("오늘의 식단을 입력해주세요!")
            
          elsif message == "아이 별 정보 입력하기"
            @parent.update(:state => 'input_kid_info')
            return jsonHelper.messageJson("입력을 할 아이의 이름을 입력해주세요!")
            
          elsif message == "담임교사 한마디 입력하기"
            @parent.update(:state => 'input_kid_comment')
            return jsonHelper.messageJson("담임교사 한마디를 입력해주세요!")
            
          elsif message == "식사량 입력하기"
            @parent.update(:state => 'input_kid_food')
            return jsonHelper.messageJson("아이의 오늘 식사량을 입력해주세요!(%)")
          else
           return jsonHelper.buttonJson("안녕하세요 킨더가드 입니다! 메뉴를 선택해주세요!",["공지사항 입력하기", "바깥활동시간 입력하기","식단 입력하기","아이 별 정보 입력하기","아이 별 정보 조회하기"])
          end
        elsif @parent_state == "input_notice"
            if Dailyinfo.all.find_by(kid_name: "all", date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: "all", notice: "#{message}", date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("공지사항 등록이 완료되었습니다!",["돌아가기"])
            else
                Dailyinfo.all.find_by(kid_name: "all",date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code).update(:notice => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("공지사항 등록이 완료되었습니다!",["돌아가기"])
            end
        elsif @parent_state == "input_outer"
            if Dailyinfo.all.find_by(kid_name: "all", date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: "all", outer_time: "#{message}", date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 바깥활동시간 등록이 완료되었습니다!",["돌아가기"])
            else
                Dailyinfo.all.find_by(kid_name: "all",date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code).update(:outer_time => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 바깥활동시간 등록이 완료되었습니다!",["돌아가기"])
            end    
        elsif @parent_state == "input_food_text"
            if Dailyinfo.all.find_by(kid_name: "all", date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: "all", food_text: "#{message}", date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 식단 등록이 완료되었습니다!",["돌아가기"])
            else
                Dailyinfo.all.find_by(kid_name: "all",date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code).update(:food_text => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 식단 등록이 완료되었습니다!",["돌아가기"])
            end    
        elsif @parent_state == "input_kid_info"
            if Dailyinfo.all.find_by(kid_name: message, date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: message, date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init', :input_kid => message)
                return jsonHelper.buttonJson("#{message} 아이에 대한 정보를 입력하시는군요!",["담임교사 한마디 입력하기","식사량 입력하기"])
            else
                @parent.update(:state => 'init', :input_kid => message)
                return jsonHelper.buttonJson("#{message} 아이에 대한 정보를 입력하시는군요!",["담임교사 한마디 입력하기","식사량 입력하기"])
            end  
        elsif @parent_state == "input_kid_comment"
                @parent_kid = @parent.input_kid
                Dailyinfo.all.find_by(kid_name: @parent_kid, date: "#{Date.today.strftime("%m%d")}").update(:kid_comment => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("#{@parent_kid}아이에 대한 정보가 입력되었습니다",["돌아가기"])
        elsif @parent_state == "input_kid_food"
                @parent_kid = @parent.input_kid
                Dailyinfo.all.find_by(kid_name: @parent_kid, date: "#{Date.today.strftime("%m%d")}").update(:kid_food => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("#{@parent_kid}아이에 대한 식사량정보가 입력되었습니다",["돌아가기"])
        end
        
      end
     
        
        
    elsif Parent.all.find_by(kakao_id: userkey).usertype == "학부모"
      @parent = Parent.all.find_by(kakao_id: userkey)
      @parent_scenario = Parent.all.find_by(kakao_id: userkey).scenario
      @parent_state = Parent.all.find_by(kakao_id: userkey).state
      
      if @parent_scenario == "1"
        if @parent_state == "center_regi"
            @parent.update(:center_code => message, :state => 'name_regi')
            return jsonHelper.messageJson("아이의 이름을 입력해주세요!")
        elsif @parent_state == "name_regi"
            @center_code = @parent.center_code.to_i
            @Center = Center.all.find_by(id: @center_code)
            @parent.update(:name => message, :registered => '1', :scenario => '100', :state => 'init')
            @parent_name = @parent.name
            return jsonHelper.buttonJson("안녕하세요 #{@Center.title}에 다니고 있는 #{@parent.name} 아이의 학부모님! \n등록이 완료되었습니다!",["시작하기"])
        end
        
      elsif @parent_scenario == "100"
        if @parent_state == "init"
          if message ==  "아이 정보 열람하기"
            @parent.update(:state => 'input_notice')
            return jsonHelper.messageJson("공지사항을 입력해주세요!")
            
          elsif message == "부모님 코멘트 입력하기"
            @parent.update(:state => 'input_parent_comment')  
            return jsonHelper.messageJson("오늘의 바깥활동시간을 입력해주세요!(분)")
          else
           return jsonHelper.buttonJson("안녕하세요 킨더가드 입니다! 메뉴를 선택해주세요!",["아이 정보 열람하기", "부모님 코멘트 입력하기"])
          end
        elsif @parent_state == "input_notice"
            if Dailyinfo.all.find_by(kid_name: "all", date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: "all", notice: "#{message}", date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("공지사항 등록이 완료되었습니다!",["돌아가기"])
            else
                Dailyinfo.all.find_by(kid_name: "all",date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code).update(:notice => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("공지사항 등록이 완료되었습니다!",["돌아가기"])
            end
        elsif @parent_state == "input_parent_comment"
            if Dailyinfo.all.find_by(kid_name: "all", date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: "all", outer_time: "#{message}", date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 바깥활동시간 등록이 완료되었습니다!",["돌아가기"])
            else
                Dailyinfo.all.find_by(kid_name: "all",date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code).update(:outer_time => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 바깥활동시간 등록이 완료되었습니다!",["돌아가기"])
            end    
        elsif @parent_state == "input_food_text"
            if Dailyinfo.all.find_by(kid_name: "all", date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: "all", food_text: "#{message}", date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 식단 등록이 완료되었습니다!",["돌아가기"])
            else
                Dailyinfo.all.find_by(kid_name: "all",date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code).update(:food_text => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("오늘의 식단 등록이 완료되었습니다!",["돌아가기"])
            end    
        elsif @parent_state == "input_kid_info"
            if Dailyinfo.all.find_by(kid_name: message, date: "#{Date.today.strftime("%m%d")}") == nil
                Dailyinfo.create(kid_name: message, date: "#{Date.today.strftime("%m%d")}", center_code: @parent.center_code)
                @parent.update(:state => 'init', :input_kid => message)
                return jsonHelper.buttonJson("#{message} 아이에 대한 정보를 입력하시는군요!",["담임교사 한마디 입력하기","식사량 입력하기"])
            else
                @parent.update(:state => 'init', :input_kid => message)
                return jsonHelper.buttonJson("#{message} 아이에 대한 정보를 입력하시는군요!",["담임교사 한마디 입력하기","식사량 입력하기"])
            end  
        elsif @parent_state == "input_kid_comment"
                @parent_kid = @parent.input_kid
                Dailyinfo.all.find_by(kid_name: @parent_kid, date: "#{Date.today.strftime("%m%d")}").update(:kid_comment => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("#{@parent_kid}아이에 대한 정보가 입력되었습니다",["돌아가기"])
        elsif @parent_state == "input_kid_food"
                @parent_kid = @parent.input_kid
                Dailyinfo.all.find_by(kid_name: @parent_kid, date: "#{Date.today.strftime("%m%d")}").update(:kid_food => message)
                @parent.update(:state => 'init')
                return jsonHelper.buttonJson("#{@parent_kid}아이에 대한 식사량정보가 입력되었습니다",["돌아가기"])
        end
        
      end
    
    end
    
    

end

    
end