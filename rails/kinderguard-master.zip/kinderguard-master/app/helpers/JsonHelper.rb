class JsonHelper
    
    
    def messageJson(text)
        @msg = {
              message: {
                  text: "#{text}"
              },
              keyboard: {
                type: "text",
              }
            }
            
        return @msg
    end
    
    def buttonJson(text, button)
        @msg = {
              message: {
                  text: "#{text}"
              },
              keyboard: {
                type: "buttons",
                buttons: button
              }
            }
            
        return @msg
    end
    
    
    def labelJson(text,label,url)
       @msg = {
              message: {
                  text: "#{text}",
              message_button: {
               label: "#{label}",
                url: "#{url}"
              }
              },
              keyboard: {
                type: "text",
              }
            }
            
        return @msg
    end    
    
    
    
end