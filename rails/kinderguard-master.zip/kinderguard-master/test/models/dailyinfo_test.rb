require 'test_helper'

class DailyinfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
