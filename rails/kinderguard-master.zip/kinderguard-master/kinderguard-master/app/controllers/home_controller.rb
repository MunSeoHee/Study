require 'will_paginate'
require 'JsonHelper'
require 'Scenario'

class HomeController < ApplicationController
  def index
    @center = Center.all
    @centerRank = @center.order("id DESC")
    @center_first = @centerRank.first
    @center_second = @centerRank.second
    @center_third = @centerRank.third

  end

  def detail
    @center = Center.find(params[:id])
    
    @service_array = Array.new
    @center.service.split(",").each do |x|
      @service_array << x
    end
    
    @review = @center.reviews
    
    @sum = 0
    
    @review.all.each do |x|
      @sum += x.total_rate
    end
    
    @average = @sum / (@review.all.count.to_f)
  end

  def review
  end

  def list
    @search = Center.search do
        fulltext params[:search]
        paginate :page => params[:page], :per_page => 5
    end
    @center = @search.results
    # @center = Center.paginate(:page => params[:page])
  end
  
  def keyboard_init
       @msg =
            {
              type: "buttons",
              buttons: ["시작하기"]
            }
        render json: @msg, status: :ok
  end
  
  def chat_control
    jsonHelper = JsonHelper.new
    scenario = Scenario.new
    
    @response = params[:content]
    @user_key = params[:user_key]
    
    if @response == "시작하기" || @response == "돌아가기"
      if Parent.all.find_by(kakao_id: "#{@user_key}") == nil
       render json: jsonHelper.buttonJson("안녕하세요, 킨더가드 입니다! 어린이집 선생님이신가요? 학부모신가요?", ["선생님","학부모"])
      else
       render json: scenario.rule(@user_key,@response)
      end
    else
       render json: scenario.rule(@user_key,@response)
    end
      
    
  end
    
end
