Rails.application.routes.draw do
  root 'home#index'
  
  get 'home/:id' => 'home#detail'

  get 'home/review'

  get 'list' => 'home#list'
  
  get '/keyboard' => 'home#keyboard_init'
  post '/message' => 'home#chat_control'
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
