Rails.application.routes.draw do
  root 'home#index'
  
  get 'home/:id' => 'home#detail'

  get 'home/review/write' => 'home#review'
  
  get 'home/detail'

  get 'home/kinder/list' => 'home#list'
  
  get '/keyboard' => 'home#keyboard_init'
  post '/message' => 'home#chat_control'
  
  # 리뷰 상세페이지 
  get '/home/review/example' => 'home#review_example'
 
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
