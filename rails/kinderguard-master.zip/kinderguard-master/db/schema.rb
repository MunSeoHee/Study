# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20180824125638) do

  create_table "centers", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "title"
    t.string   "address"
    t.string   "city"
    t.string   "homepage"
    t.string   "workhour"
    t.string   "number"
    t.string   "service"
    t.string   "service_link"
    t.string   "centertype",               default: "국공립"
    t.float    "latitude",      limit: 24
    t.float    "longitude",     limit: 24
    t.string   "mainimage"
    t.string   "subimage1"
    t.string   "subimage2"
    t.integer  "review_number"
    t.float    "total_rate",    limit: 24
    t.float    "teacher_rate",  limit: 24
    t.float    "edu_rate",      limit: 24
    t.float    "fac_rate",      limit: 24
    t.datetime "created_at",               default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "updated_at",               default: -> { "CURRENT_TIMESTAMP" }, null: false
  end

  create_table "daily_infos", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "date"
    t.string   "food_image"
    t.string   "food_text"
    t.string   "outer_time"
    t.string   "notice"
    t.string   "kid_name"
    t.string   "center_code"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  create_table "dailyinfos", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "date"
    t.string   "food_image"
    t.string   "food_text"
    t.string   "outer_time"
    t.string   "notice"
    t.string   "kid_name"
    t.string   "center_code"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.string   "kid_comment"
    t.string   "parent_comment"
    t.string   "kid_food"
  end

  create_table "parents", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "name"
    t.string   "kakao_id"
    t.string   "center_code"
    t.string   "scenario"
    t.string   "state"
    t.string   "registered"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.string   "usertype"
    t.string   "input_kid"
  end

  create_table "reviews", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer  "child_age"
    t.string   "teacher_name"
    t.float    "teacher_rate",    limit: 24
    t.text     "teacher_content", limit: 65535
    t.integer  "visit_center"
    t.float    "fac_rate",        limit: 24
    t.text     "fac_content",     limit: 65535
    t.float    "total_rate",      limit: 24
    t.text     "total_content",   limit: 65535
    t.integer  "center_id"
    t.datetime "created_at",                    default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "updated_at",                    default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.index ["center_id"], name: "index_reviews_on_center_id", using: :btree
  end

  create_table "teachers", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "name"
    t.string   "center_id"
    t.string   "kakao_id"
    t.string   "scenario"
    t.string   "state"
    t.string   "registered"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_foreign_key "reviews", "centers"
end
