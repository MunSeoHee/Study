class AddKidFoodToDailyinfo < ActiveRecord::Migration[5.0]
  def change
    add_column :dailyinfos, :kid_food, :string
  end
end
