class CreateReviews < ActiveRecord::Migration[5.0]
  def change
    create_table :reviews do |t|
      t.integer :child_age
      t.string :teacher_name
      t.float :teacher_rate
      t.text :teacher_content
      t.integer :visit_center
      t.float :fac_rate
      t.text :fac_content
      t.float :total_rate
      t.text :total_content
      t.references :center, foreign_key: true

      t.timestamps
    end
  end
end
