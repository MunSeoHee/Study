class AddParentCommentToDailyinfo < ActiveRecord::Migration[5.0]
  def change
    add_column :dailyinfos, :parent_comment, :string
  end
end
