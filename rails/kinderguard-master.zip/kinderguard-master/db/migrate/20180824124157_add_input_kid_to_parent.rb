class AddInputKidToParent < ActiveRecord::Migration[5.0]
  def change
    add_column :parents, :input_kid, :string
  end
end
