class CreateParents < ActiveRecord::Migration[5.0]
  def change
    create_table :parents do |t|
      t.string :name
      t.string :kakao_id
      t.string :center_code
      t.string :scenario
      t.string :state
      t.string :registered

      t.timestamps
    end
  end
end
