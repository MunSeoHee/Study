class CreateCenters < ActiveRecord::Migration[5.0]
  def change
    create_table :centers do |t|
      t.string :title
      t.string :address
      t.string :city
      t.string :homepage
      t.string :workhour
      t.string :number
      t.string :service
      t.string :service_link
      t.string :centertype
      t.float :latitude
      t.float :longitude
      t.string :mainimage
      t.string :subimage1
      t.string :subimage2
      t.integer :review_number
      t.float :total_rate
      t.float :teacher_rate
      t.float :edu_rate
      t.float :fac_rate

      t.timestamps
    end
  end
end
