class CreateDailyinfos < ActiveRecord::Migration[5.0]
  def change
    create_table :dailyinfos do |t|
      t.string :date
      t.string :food_image
      t.string :food_text
      t.string :outer_time
      t.string :notice
      t.string :kid_name
      t.string :center_code

      t.timestamps
    end
  end
end
