class UtilitiesController < ApplicationController
    
    def lucky
        numbers = (1..45).to_a
        random_numbers=numbers.sample 6
        @lucky_numbers = random_numbers.sort
    end
    
end
