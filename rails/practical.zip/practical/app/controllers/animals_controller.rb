class AnimalsController < ApplicationController
    
    def dog
        
    end
    
    def index
    end
    
end
