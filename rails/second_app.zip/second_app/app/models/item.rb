class Item < ApplicationRecord
    #Item은 Owner에게 속해 있어요
    belongs_to :owner
end
