class Movie < ApplicationRecord
end
