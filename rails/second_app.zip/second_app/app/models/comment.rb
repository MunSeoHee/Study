class Comment < ApplicationRecord
  belongs_to :note
end
