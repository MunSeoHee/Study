class Hobby < ApplicationRecord
  belongs_to :owner
end
