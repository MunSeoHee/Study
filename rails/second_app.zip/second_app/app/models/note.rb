class Note < ApplicationRecord
    has_many :comments
end
