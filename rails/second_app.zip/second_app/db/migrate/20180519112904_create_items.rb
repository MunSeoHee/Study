class CreateItems < ActiveRecord::Migration[5.0]
  def change
    create_table :items do |t|
      t.string :name
      t.belongs_to :owner
      
      # t.integer :owner_id
      # t.reference :owner (참조)
      # t.belongs_to :owner (속함)
      #셋이 다 똑같음
      

      t.timestamps
    end
  end
end
