Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  
  #<Note>
  #Create
  get '/notes/new' => 'notes#new'
  post '/notes' => 'notes#create'
  
  #Read
  get '/notes' => 'notes#index'
  get '/notes/:id' => 'notes#show'    #:id라고 해놓고 notes/1이라고 입력하면 id = 1이 됨
  
  #Update
  get '/notes/:id/edit' => 'notes#edit'
  patch '/notes/:id' => 'notes#update'
  
  #Destroy
  delete '/notes/:id' => 'notes#destroy'
  
  #<comment>
  #create
  post '/comments' => 'comments#create'
  
  #destroy
  delete '/comments/:id' => 'comments#destroy'
end
